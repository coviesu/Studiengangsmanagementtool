package com.Knaben.ModuleManagement.Controller;

import com.Knaben.ModuleManagement.Entity.ExamEntity;
import com.Knaben.ModuleManagement.Entity.ModuleEntity;
import com.Knaben.ModuleManagement.Request.ExamRequest;
import com.Knaben.ModuleManagement.Service.ModuleService;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RequiredArgsConstructor
@RestController
@RequestMapping("/modul")
public class ModuleController {

    private final ModuleService moduleService;

    //Anzeige aller Module
    @GetMapping
    public ResponseEntity<List<ModuleEntity>> getModule(){
        return new ResponseEntity<>(moduleService.getModule(), HttpStatus.OK);
    }

    //Pro Modul: Anzeige der Modul-Details
    @GetMapping(path = "{moduleId}")
    public ResponseEntity<ModuleEntity> getModuleById(@PathVariable Long moduleId){
        return new ResponseEntity<>(moduleService.getModuleInfo(moduleId), HttpStatus.OK);
    }

    //Erstellung eines Moduls
    @PostMapping("/create")
    public ResponseEntity<ModuleEntity> addModule(@RequestBody ModuleEntity moduleEntity){
        return new ResponseEntity<>(moduleService.addModule(moduleEntity), HttpStatus.CREATED);
    }

    //Update eines Moduls
    @PutMapping(path = "{moduleId}")
    public ResponseEntity<ModuleEntity> updateModule(@PathVariable Long moduleId, @RequestBody ModuleEntity moduleEntity) {
        return new ResponseEntity<>(moduleService.updateModule(moduleId, moduleEntity), HttpStatus.OK);
    }

    //Pflegen von mehreren Klausurterminen pro Modul
    @PostMapping(path = "{moduleId}/exam")
    public ResponseEntity<ExamEntity> setExam(@PathVariable Long moduleId, @RequestBody ExamRequest examRequest) {
        return new ResponseEntity<>(moduleService.setExam(moduleId, examRequest), HttpStatus.CREATED);
    }

    //Anzeige der verfügbaren Plätze pro Klausurtermin
    @GetMapping(path = "/exam/{examId}/availableSeats")
    public ResponseEntity<Integer> getAvailableSeats(@PathVariable Long examId) {
        return new ResponseEntity<>(moduleService.getExamInfo(examId).getAvailableSeats(), HttpStatus.OK);
    }

    //View examentity Information for each module
    @GetMapping(path = "{moduleId}/exam")
    public ResponseEntity<List<ExamEntity>> getExamInfo(@PathVariable Long moduleId) {
        return new ResponseEntity<>(moduleService.getExam(moduleId), HttpStatus.OK);
    }

    //Löschen eines Moduls (Solange kein Student eingeschrieben ist)
    @DeleteMapping(path = "{moduleId}")
    public ResponseEntity<String> delModule(@PathVariable Long moduleId){
        return new ResponseEntity<>(moduleService.delModule(moduleId) ,HttpStatus.ACCEPTED);
    }
}
