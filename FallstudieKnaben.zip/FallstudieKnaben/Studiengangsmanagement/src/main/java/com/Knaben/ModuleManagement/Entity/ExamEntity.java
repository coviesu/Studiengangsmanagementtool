package com.Knaben.ModuleManagement.Entity;

import jakarta.persistence.*;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;
import java.util.HashSet;
import java.util.Set;

@Data
@Entity
@NoArgsConstructor
public class ExamEntity {
    @Id
    @GeneratedValue(strategy= GenerationType.AUTO)
    private long id;

    private LocalDate examDate;

    private int seats = 0;

    private long moduleId;

    @OneToMany
    private Set<UserEntity> participants = new HashSet<>();

    public ExamEntity(LocalDate examDate, int seats, long moduleId) {
        this.examDate = examDate;
        this.seats = seats;
        this.moduleId = moduleId;
    }

    public void addParticipant(UserEntity user) {
        if (participants.size() >= seats) {
            throw new IllegalStateException("No available seats");
        }
        participants.add(user);
    }

    //Get the number of available seats
    public int getAvailableSeats() {
        return seats - participants.size();
    }

}
