package com.Knaben.ModuleManagement.Controller;

import com.Knaben.ModuleManagement.Entity.UserEntity;
import com.Knaben.ModuleManagement.Service.LoginService;
import jakarta.servlet.http.Cookie;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import lombok.RequiredArgsConstructor;
import org.apache.catalina.User;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.Arrays;
import java.util.Optional;

@RequiredArgsConstructor
@RestController
public class LoginController {

    private final LoginService loginService;
/*
    //Ein Nutzer kann sich mit Nutzername und Passwort anmelden
    @PostMapping("/login")
    public ResponseEntity<UserEntity> login(HttpServletResponse response,@RequestParam String username, @RequestParam String password){
        return new ResponseEntity<>(loginService.login(username, password, response), HttpStatus.ACCEPTED);
    }*/
@PostMapping("/login")
public ResponseEntity<?> login(HttpServletResponse response, @RequestParam(required = false) String username, @RequestParam(required = false) String password) {
    // Prüfen, ob Benutzername oder Passwort fehlen
    if (username == null || username.isBlank() || password == null || password.isBlank()) {
        String missingFields = "Fehler: ";
        if (username == null || username.isBlank()) missingFields += "Benutzername ";
        if (password == null || password.isBlank()) missingFields += "Passwort ";
        missingFields += "fehlen.";
        return ResponseEntity.badRequest().body(missingFields.trim());
    }

    // Direkt die ResponseEntity von der login-Methode des LoginService zurückgeben
    return loginService.login(username, password, response);
}
    //Logout-Methode zum Abmelden des Users
    @PostMapping("/logout")
    public ResponseEntity<?> logout(HttpServletRequest request, HttpServletResponse response) {
        // Versuch, die Benutzer-ID aus dem Cookie zu extrahieren
        Long userId = null;
        Cookie[] cookies = request.getCookies();
        if (cookies != null) {
            for (Cookie cookie : cookies) {
                if ("sessionID".equals(cookie.getName())) {
                    try {
                        userId = Long.parseLong(cookie.getValue());
                        break;
                    } catch (NumberFormatException e) {
                        return ResponseEntity.badRequest().body("Fehler: Ungültige Session-ID.");
                    }
                }
            }
        }

        if (userId == null) {
            return ResponseEntity.badRequest().body("Fehler: Keine Session-ID gefunden.");
        }

        // Logout-Logik im Service
        ResponseEntity<?> logoutResponse = loginService.logout(userId);

        // Cookie löschen, wenn Logout erfolgreich war
        if (logoutResponse.getStatusCode() == HttpStatus.OK) {
            System.out.println(Arrays.toString(cookies));
            Cookie logoutCookie = new Cookie("sessionID", null);
            logoutCookie.setMaxAge(0);
            logoutCookie.setPath("/");
            response.addCookie(logoutCookie);
            System.out.println(Arrays.toString(cookies));
        }

        return logoutResponse;
    }

}
