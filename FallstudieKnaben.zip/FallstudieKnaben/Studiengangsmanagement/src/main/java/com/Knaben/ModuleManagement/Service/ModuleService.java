package com.Knaben.ModuleManagement.Service;

import com.Knaben.ModuleManagement.DataBase.ExamRepository;
import com.Knaben.ModuleManagement.DataBase.ModuleRepository;
import com.Knaben.ModuleManagement.DataBase.UserRepository;
import com.Knaben.ModuleManagement.Entity.ExamEntity;
import com.Knaben.ModuleManagement.Entity.ModuleEntity;
import com.Knaben.ModuleManagement.Request.ExamRequest;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
public class ModuleService {

    private final ModuleRepository moduleRepository;
    private final ExamRepository examRepository;
    private final UserService userService;

    public List<ModuleEntity> getModule() {
        return moduleRepository.findAll();
    }

    public ModuleEntity getModuleInfo(Long moduleId) {
        return moduleRepository.findModuleById(moduleId);
    }

    public ModuleEntity addModule(ModuleEntity moduleEntity) {
        return moduleRepository.save(moduleEntity);
    }

    public String delModule(Long moduleId) {
        if(moduleRepository.findModuleById(moduleId).getEnrolledEntities().isEmpty()) {
            //check if all user have module in watchlist if yes delete the module from watchlist
            userService.removeFromAllWatchlist(moduleId);
            moduleRepository.deleteById(moduleId);
            return "Module Deleted";
        }
        return "Students are enrolled";
    }

    public ExamEntity setExam(Long moduleId, ExamRequest examRequest) {
        ModuleEntity module = moduleRepository.findModuleById(moduleId);
        ExamEntity exam = module.setExam(examRequest.getExamDate(), examRequest.getSeats());
        return examRepository.save(exam);
    }

    public List<ExamEntity> getExam(Long moduleId) {
        return examRepository.findAllByModuleId(moduleId);
    }

    public ExamEntity getExamInfo(Long examId) {
        return examRepository.findById(examId).orElse(null);
    }

    public ModuleEntity updateModule(Long moduleId, ModuleEntity moduleEntity) {
        ModuleEntity existingModule = moduleRepository.findModuleById(moduleId);
        if (existingModule != null) {
            existingModule.setName(moduleEntity.getName());
            existingModule.setDescription(moduleEntity.getDescription());
            existingModule.setEcts(moduleEntity.getEcts());
            existingModule.setLecturer(moduleEntity.getLecturer());
            existingModule.setDepartment(moduleEntity.getDepartment());
            existingModule.setRegularSchedule(moduleEntity.getRegularSchedule());
            existingModule.setLiteratureRecommendation(moduleEntity.getLiteratureRecommendation());
            existingModule.setSemester(moduleEntity.getSemester());
            return moduleRepository.save(existingModule);
        }
        return null;
    }
}