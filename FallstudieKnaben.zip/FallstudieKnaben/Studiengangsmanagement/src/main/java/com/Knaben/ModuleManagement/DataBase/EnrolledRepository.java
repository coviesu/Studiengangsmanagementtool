package com.Knaben.ModuleManagement.DataBase;

import com.Knaben.ModuleManagement.Entity.EnrolledEntity;
import org.springframework.data.jpa.repository.JpaRepository;

public interface EnrolledRepository
        extends JpaRepository<EnrolledEntity, Long> {
    EnrolledEntity findByUserIdAndModuleId(Long userId, Long moduleId);
}
