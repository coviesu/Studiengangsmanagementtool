package com.Knaben.ModuleManagement.Config;

import com.Knaben.ModuleManagement.DataBase.UserRepository;
import com.Knaben.ModuleManagement.Entity.UserEntity;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class UserConfig {
    @Bean
    CommandLineRunner commandLineRunner2(UserRepository userRepository){
        return args -> {
            UserEntity user1 = new UserEntity();
            user1.setUsername("JohnDoe");
            user1.setPassword("password1");
            user1.setFullName("John Doe");
            user1.setEmail("john.doe@example.com");
            user1.setSemester(6);

            UserEntity user2 = new UserEntity();
            user2.setUsername("JaneDoe2");
            user2.setPassword("password2");
            user2.setFullName("Jane Doe2");
            user2.setEmail("jane.doe2@example.com");
            user2.setSemester(6);

            UserEntity user3 = new UserEntity();
            user3.setUsername("AlexSmith");
            user3.setPassword("password3");
            user3.setFullName("Alex Smith");
            user3.setEmail("alex.smith@example.com");
            user3.setSemester(6);

            UserEntity user4 = new UserEntity();
            user4.setUsername("EmilyJohnson");
            user4.setPassword("password4");
            user4.setFullName("Emily Johnson");
            user4.setEmail("emily.johnson@example.com");
            user4.setSemester(6);

            UserEntity user5 = new UserEntity();
            user5.setUsername("PatrickStar");
            user5.setPassword("password5");
            user5.setFullName("Patrick Star");
            user5.setEmail("patrick.star@example.com");
            user5.setSemester(2);


            userRepository.save(user1);
            userRepository.save(user2);
            userRepository.save(user3);
            userRepository.save(user4);
            userRepository.save(user5);
        };
    }
}
