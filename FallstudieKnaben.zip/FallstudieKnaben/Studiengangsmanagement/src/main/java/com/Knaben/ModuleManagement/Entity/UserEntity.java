package com.Knaben.ModuleManagement.Entity;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.HashSet;
import java.util.Set;

@Getter
@Setter
@Entity
@Table
@NoArgsConstructor
public class UserEntity {

        @Id
        @GeneratedValue(strategy = GenerationType.AUTO)
        private long id;

        private String username;
        private String password;
        private String fullName;
        private String email;
        private int Semester;
        private boolean loggedIn = false;
        @Lob
        @Column(length = Integer.MAX_VALUE)
        private byte[] profilePicture;



        @ManyToMany(fetch = FetchType.EAGER, cascade = CascadeType.ALL)
        @JoinTable(
                name = "user_module_watchlist",
                joinColumns = @JoinColumn(name = "user_id"),
                inverseJoinColumns = @JoinColumn(name = "module_id")
        )
        private Set<ModuleEntity> watchlist = new HashSet<>();

        @OneToMany(fetch = FetchType.EAGER)
        @JoinColumn(name = "user_enrolled")
        private Set<EnrolledEntity> enrolledEntities = new HashSet<>();
}
