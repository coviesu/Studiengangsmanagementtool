package com.Knaben.ModuleManagement.DataBase;

import com.Knaben.ModuleManagement.Entity.ModuleEntity;
import org.springframework.data.jpa.repository.JpaRepository;


public interface ModuleRepository extends JpaRepository<ModuleEntity, Long> {


    ModuleEntity findModuleById(Long moduleId);
}
