package com.Knaben.ModuleManagement.Request;

import com.Knaben.ModuleManagement.Entity.EnrolledEntity;
import com.Knaben.ModuleManagement.Entity.ModuleEntity;
import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

import java.util.Set;

@Getter
@Setter
@Builder
public class SignUpRequest {
    private String username;
    private String password;
    private String fullName;
    private String email;
    private int semester;
    private Set<ModuleEntity> watchlist;
    private Set<EnrolledEntity> enrolledEntities;

}
