package com.Knaben.ModuleManagement.Request;

import lombok.Data;

import java.time.LocalDate;

@Data
public class ExamRequest {

    private LocalDate examDate;
    private int seats;
}
