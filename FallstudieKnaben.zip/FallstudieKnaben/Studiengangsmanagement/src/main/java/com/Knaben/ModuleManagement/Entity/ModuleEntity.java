package com.Knaben.ModuleManagement.Entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;
import java.util.HashSet;
import java.util.Set;

@Data
@Entity
@Table
@NoArgsConstructor
@AllArgsConstructor
public class ModuleEntity {


    @Id
    @GeneratedValue(strategy=GenerationType.AUTO)
    private long id;

    private String name;
    private String description;
    private int ects;
    private String lecturer;
    private String department;
    private String regularSchedule;
    private String literatureRecommendation;
    private int semester;

    @OneToMany
    @JoinColumn(name = "module_enrolled")
    private Set<EnrolledEntity> enrolledEntities = new HashSet<>();
    public ModuleEntity(String name,
                        String description,
                        int ects,
                        String lecturer,
                        String department,
                        String regularSchedule,
                        String literatureRecommendation,
                        int semester) {
        this.name = name;
        this.description = description;
        this.ects = ects;
        this.lecturer = lecturer;
        this.department = department;
        this.regularSchedule = regularSchedule;
        this.literatureRecommendation = literatureRecommendation;
        this.semester = semester;
    }

    public ExamEntity setExam(LocalDate examDate, int seats){
        return new ExamEntity(examDate, seats, this.id);
    }
}
