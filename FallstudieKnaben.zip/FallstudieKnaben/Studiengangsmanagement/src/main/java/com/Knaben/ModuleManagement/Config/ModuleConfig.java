package com.Knaben.ModuleManagement.Config;

import com.Knaben.ModuleManagement.DataBase.ModuleRepository;
import com.Knaben.ModuleManagement.Entity.ModuleEntity;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.util.List;

@Configuration
public class ModuleConfig {
    @Bean
    CommandLineRunner commandLineRunner(ModuleRepository repository){
        return args -> {
            ModuleEntity moduleEntity1 = new ModuleEntity(
                    "Introduction to Computer Science",
                    "An introductory course covering fundamental concepts of computer science.",
                    6,
                    "Dr. Smith",
                    "Computer Science",
                    "Monday, Wednesday, Friday 10:00 AM - 12:00 PM",
                    "Computer Science Illuminated by Nell Dale and John Lewis",
                    2
            );
            ModuleEntity moduleEntity2 = new ModuleEntity(
                    "Calculus I",
                    "A foundational course in calculus, covering limits, derivatives, and integrals.",
                    5,
                    "Prof. Johnson",
                    "Mathematics",
                    "Tuesday, Thursday 1:00 PM - 3:00 PM",
                    "Calculus: Early Transcendentals by James Stewart",
                    2
            );
            ModuleEntity moduleEntity3 = new ModuleEntity(
                    "Introduction to Marketing",
                    "An overview of basic marketing principles and strategies.",
                    4,
                    "Dr. Miller",
                    "Business Administration",
                    "Monday, Wednesday 2:00 PM - 4:00 PM",
                    "Principles of Marketing by Philip Kotler and Gary Armstrong",
                    2
            );
            ModuleEntity moduleEntity4 = new ModuleEntity(
                    "German Literature",
                    "A study of prominent works in German literature.",
                    5,
                    "Prof. Schmidt",
                    "German Studies",
                    "Tuesday, Thursday 10:00 AM - 12:00 PM",
                    "Faust by Johann Wolfgang von Goethe",
                    2
            );
            ModuleEntity moduleEntity5 = new ModuleEntity(
                    "Organic Chemistry",
                    "An examination of organic chemical compounds and their properties.",
                    6,
                    "Dr. Brown",
                    "Chemistry",
                    "Monday, Wednesday, Friday 9:00 AM - 11:00 AM",
                    "Organic Chemistry by Paula Yurkanis Bruice",
                    2
            );
            ModuleEntity moduleEntity6 = new ModuleEntity(
                    "Introduction to Psychology",
                    "An introduction to the basic concepts and theories of psychology.",
                    4,
                    "Prof. Davis",
                    "Psychology",
                    "Tuesday, Thursday 3:00 PM - 5:00 PM",
                    "Psychology by Saundra K. Ciccarelli and J. Noland White",
                    2
            );
            ModuleEntity moduleEntity7 = new ModuleEntity(
                    "World History",
                    "A survey of major events and developments in world history.",
                    5,
                    "Dr. Martinez",
                    "History",
                    "Monday, Wednesday 1:00 PM - 3:00 PM",
                    "A People's History of the World by Chris Harman",
                    2
            );
            ModuleEntity moduleEntity8 = new ModuleEntity(
                    "Introduction to Sociology",
                    "An overview of key sociological concepts and theories.",
                    4,
                    "Prof. Wilson",
                    "Sociology",
                    "Tuesday, Thursday 11:00 AM - 1:00 PM",
                    "Sociology: A Brief Introduction by Richard T. Schaefer",
                    2
            );
            ModuleEntity moduleEntity9 = new ModuleEntity(
                    "Environmental Science",
                    "A study of environmental issues and solutions.",
                    5,
                    "Dr. Adams",
                    "Environmental Studies",
                    "Monday, Wednesday, Friday 2:00 PM - 4:00 PM",
                    "Environmental Science: Toward a Sustainable Future by Richard T. Wright and Dorothy Boorse",
                    2
            );
            ModuleEntity moduleEntity10 = new ModuleEntity(
                    "Business Ethics",
                    "An exploration of ethical principles in business decision-making.",
                    4,
                    "Prof. Taylor",
                    "Business Ethics",
                    "Tuesday, Thursday 2:00 PM - 4:00 PM",
                    "Business Ethics: Ethical Decision Making & Cases by O. C. Ferrell and John Fraedrich",
                    2
            );
            repository.saveAll(
                    List.of(
                            moduleEntity1,moduleEntity2,
                            moduleEntity3,moduleEntity4,
                            moduleEntity5,moduleEntity6,
                            moduleEntity7,moduleEntity8,
                            moduleEntity9,moduleEntity10)
            );
        };
    }
}
