package com.Knaben.ModuleManagement.Entity;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import lombok.Data;

@Entity
@Data
public class EnrolledEntity {

    @Id
    @GeneratedValue(strategy= GenerationType.AUTO)
    private long id;

    private long moduleId;
    private long userId;

    private double grade;
    private boolean completed = (grade!=0);

    private double rating;
}
