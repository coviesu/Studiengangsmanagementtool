package com.Knaben.ModuleManagement.Controller;

import com.Knaben.ModuleManagement.Entity.ExamEntity;
import com.Knaben.ModuleManagement.Entity.ModuleEntity;
import com.Knaben.ModuleManagement.Request.ResetPasswordRequest;
import com.Knaben.ModuleManagement.Service.UserService;
import com.Knaben.ModuleManagement.Entity.UserEntity;
import jakarta.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpRequest;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.Optional;
import java.util.Set;

@RestController
@RequestMapping("/UserEntity")
public class UserController {
    private final UserService userService;

    @Autowired
    public UserController(UserService userService){
        this.userService = userService;
    }


    //Gibt eine Liste aller User aus
    @GetMapping("/getUser")
    public ResponseEntity<List<UserEntity>> getUser(){
        return new ResponseEntity<>(userService.getUser(), HttpStatus.OK);
    }

    //Ausgabe der Daten des angemeldeten Benutzers
    @GetMapping("/getUserById")
    public ResponseEntity<?> getLoggedUser(HttpServletRequest request) {
        if (!userService.isUserLoggedIn(request)) {

            return new ResponseEntity<>("Kein Nutzer angemeldet. Bitte melden Sie sich an, um auf diese Information zuzugreifen.", HttpStatus.UNAUTHORIZED);
        }
        try {

            UserEntity userEntity = userService.getUserEntityById(request);
            return new ResponseEntity<>(userEntity, HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>("Benutzer nicht gefunden.", HttpStatus.NOT_FOUND);
        }
    }

    /*@GetMapping("/getUserById")
    public ResponseEntity<UserEntity> getLoggedUser(HttpServletRequest request) {
        UserEntity userEntity = userService.getUserEntityById(request);
        if (userEntity != null) {
            return new ResponseEntity<>(userEntity, HttpStatus.OK);
        } else {
            System.out.println("Momentan ist kein Nutzer angemeldet");
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }*/

    //Benutzer können sich registrieren
    @PostMapping("/addUser")
    public ResponseEntity<UserEntity> addUser(@RequestBody UserEntity userEntity){

        System.out.println("Herzlich Willkommen!");
        return new ResponseEntity<>(userService.addUser(userEntity), HttpStatus.CREATED);
    }
    //Gibt die watchlist eines Users aus
    @GetMapping("/getWatchList")
    public ResponseEntity<Set<ModuleEntity>> getWatchlist(HttpServletRequest request){
        return new ResponseEntity<>(userService.getWatchlist(request), HttpStatus.OK);
    }

    //Ein Student kann Module auf seine Merkliste setzen
    @PostMapping(path = "addToWatchlist/{moduleId}")
    public ResponseEntity<ModuleEntity> addToWatchlist(@PathVariable Long moduleId, HttpServletRequest request){
        return new ResponseEntity<>(userService.addToWatchlist(moduleId, request), HttpStatus.OK);
    }

    @PostMapping("removeFromWatchlist/{moduleId}")
    public ResponseEntity<UserEntity> removeFromWatchlist(@PathVariable Long moduleId, HttpServletRequest request){
        return new ResponseEntity<>(userService.removeFromWatchlist(userService.getSessionID(request), moduleId),HttpStatus.OK);
    }

    //Buchung von Klausurterminen pro Benutzer pro eingeschriebenen Kurs
    @PostMapping(path = "addParticipant/{examId}")
    public ResponseEntity<ExamEntity> addParticipant(@PathVariable Long examId, HttpServletRequest request) {
        return new ResponseEntity<>(userService.addParticipant(examId, request), HttpStatus.OK);
    }


    //Berechnung der gewichteten (nach ECTS) Durchschnittsnote des Studierenden
    @GetMapping(path = "calculateWeightedAverageGrade")
    public ResponseEntity<Double> calculateWeightedAverageGrade(HttpServletRequest request) {
        double averageGrade = userService.calculateWeightedAverageGrade(request);
        return new ResponseEntity<>(averageGrade, HttpStatus.OK);
    }

    //Benutzerprofil anlegen und ändern
    @PutMapping("/updateUser")
    public ResponseEntity<?> updateUser(@RequestBody UserEntity userEntity, HttpServletRequest request) {
        Optional<UserEntity> user = userService.updateUser(userEntity, request);
        if(user.isPresent()) {
            return ResponseEntity.ok(user);
        }
        return ResponseEntity.badRequest().body("User not logged in!");
    }

    //Der Nutzer kann sein Passwort zurücksetzen
    @PostMapping("/resetPassword")
    ResponseEntity<String> resetPassword(@RequestBody ResetPasswordRequest resetPasswordRequest) {
        return ResponseEntity.ok(userService.resetUserPassword(resetPasswordRequest));
    }
    //Der Nutzer kann sein Profilbild hochladen
    @PostMapping("/profile-picture")
    public ResponseEntity<String> uploadProfilePicture(@RequestParam("file") MultipartFile file, HttpServletRequest request) throws IOException {
        if(file.isEmpty() || file == null) {
            return ResponseEntity.badRequest().body("Bitte wähle  eine andere Datei aus. Die Datei muss im JPEG oder PNG-Format sein.");
        }
        return ResponseEntity.ok(userService.uploadProfilePicture(request, file));
    }


}