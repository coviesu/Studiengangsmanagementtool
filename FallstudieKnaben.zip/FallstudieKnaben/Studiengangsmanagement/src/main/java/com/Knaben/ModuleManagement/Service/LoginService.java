package com.Knaben.ModuleManagement.Service;

import com.Knaben.ModuleManagement.DataBase.UserRepository;
import com.Knaben.ModuleManagement.Entity.UserEntity;
import jakarta.servlet.http.Cookie;
import jakarta.servlet.http.HttpServletResponse;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.util.Optional;

@RequiredArgsConstructor
@Service
public class LoginService {

    private final UserRepository userRepository;


    /*public UserEntity login(String username, String password, HttpServletResponse response) {
        UserEntity userEntity = userRepository.findByUsernameAndPassword(username, password);
        if(userEntity != null) {
            sessionID = userEntity.getId();
            return userEntity;
        }
        return null;
    }*/
    //Verbesserung 2.0
    /*public UserEntity login(String username, String password, HttpServletResponse response) {
        UserEntity userEntity = userRepository.findByUsernameAndPassword(username, password);

        if (userEntity != null) {
            userEntity.setLoggedIn(true);
            userRepository.save(userEntity);
            Cookie cookie = new Cookie("sessionID", "" + userEntity.getId());
            response.addCookie(cookie);
        }
        return userEntity;
    }*/

    //User kann sich anmelden und Validierung wurde hinzugefügt -> Verbesserung 3.0
    public ResponseEntity<?> login(String username, String password, HttpServletResponse response) {
        Optional<UserEntity> userOptional = userRepository.findByUsername(username);

        if (!userOptional.isPresent()) {
            // Fall: Benutzername existiert nicht
            return ResponseEntity.badRequest().body("Fehler: Der Nutzer existiert nicht.");
        }

        UserEntity user = userOptional.get();
        if (!user.getPassword().equals(password)) {
            // Fall: Passwort ist falsch
            return ResponseEntity.badRequest().body("Fehler: Falsches Passwort.");
        }

        // Benutzer authentifizieren und Cookie setzen
        user.setLoggedIn(true);
        userRepository.save(user);
        Cookie cookie = new Cookie("sessionID", "" + user.getId());
        response.addCookie(cookie);

        System.out.println(cookie);

        return ResponseEntity.ok(user);
    }

    public ResponseEntity<?> logout(Long userId) {
        Optional<UserEntity> userOptional = userRepository.findById(userId);

        if (!userOptional.isPresent()) {
            return ResponseEntity.badRequest().body("Fehler: Benutzer nicht gefunden.");
        }

        UserEntity user = userOptional.get();
        user.setLoggedIn(false);
        userRepository.save(user);

        return ResponseEntity.ok("Erfolgreich abgemeldet.");
    }
}
