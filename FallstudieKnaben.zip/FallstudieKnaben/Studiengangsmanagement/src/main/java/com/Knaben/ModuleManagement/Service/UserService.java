package com.Knaben.ModuleManagement.Service;


import com.Knaben.ModuleManagement.DataBase.EnrolledRepository;
import com.Knaben.ModuleManagement.DataBase.ExamRepository;
import com.Knaben.ModuleManagement.DataBase.ModuleRepository;
import com.Knaben.ModuleManagement.DataBase.UserRepository;
import com.Knaben.ModuleManagement.Entity.EnrolledEntity;
import com.Knaben.ModuleManagement.Entity.ExamEntity;
import com.Knaben.ModuleManagement.Entity.ModuleEntity;
import com.Knaben.ModuleManagement.Entity.UserEntity;
import com.Knaben.ModuleManagement.Request.ResetPasswordRequest;
import jakarta.servlet.http.Cookie;
import jakarta.servlet.http.HttpServletRequest;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.catalina.User;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

@RequiredArgsConstructor
@Service
@Slf4j
public class UserService {

    private final UserRepository userRepository;

    private final ModuleRepository moduleRepository;

    private final EnrolledRepository enrolledRepository;

    private final ExamRepository examRepository;

    //Ehrlich gesagt GPT code aber ich weiß, was passiert :D
    public Long getSessionID(HttpServletRequest request) {
        Cookie[] cookies = request.getCookies();
        if (cookies != null) {
            for (Cookie cookie : cookies) {
                if ("sessionID".equals(cookie.getName())) {
                    log.info("SessionID key: {}, value: {}", cookie.getName(), cookie.getValue());
                    // Parse the cookie value to long and return
                    return Long.parseLong(cookie.getValue());
                }
            }
        }
        return 0L; // Return 0 if sessionID cookie is not found
    }

    private final LoginService loginService;


    public UserEntity addUser(UserEntity userEntity) {
        return userRepository.save(userEntity);
    }

    public List<UserEntity> getUser() {
        return userRepository.findAll();
    }

    public ModuleEntity addToWatchlist(Long moduleId, HttpServletRequest request) {
        Long sessionID = getSessionID(request);
        Optional<UserEntity> optionalUser = userRepository.findById(sessionID);
        if (optionalUser.isPresent()) {
            UserEntity user = optionalUser.get();
            user.getWatchlist().add(moduleRepository.findModuleById(moduleId));
            userRepository.save(user);
        } else {
            throw new IllegalStateException("User not found ID = " + sessionID);
        }
        return moduleRepository.findModuleById(moduleId);
    }

    public Set<ModuleEntity> getWatchlist(HttpServletRequest request) {
        Long sessionID = getSessionID(request);
        Optional<UserEntity> userOptional = userRepository.findById(sessionID);
        if (userOptional.isPresent()) {
            return userOptional.get().getWatchlist();
        } else {
            throw new IllegalStateException("No UserEntity found with ID = " + sessionID);
        }
    }

    public void removeFromAllWatchlist(long moduleId) {
        List<UserEntity> lue = userRepository.findAll();
        for (UserEntity u : lue) {
            removeFromWatchlist(u.getId(), moduleId);
        }
    }

    public UserEntity removeFromWatchlist(long userId, long moduleId) {
        Set<ModuleEntity> m;
        Optional<UserEntity> userOptional = userRepository.findById(userId);
        if (userOptional.isPresent()) {
            m = userOptional.get().getWatchlist();
            for (ModuleEntity ME : m) {
                if (ME.getId() == moduleId) {
                    m.remove(ME);
                    userOptional.get().setWatchlist(m);
                    userRepository.save(userOptional.get());
                    return userOptional.get();
                }
            }
        } else {
            throw new IllegalStateException("No UserEntity found with ID = " + userId);
        }
        throw new IllegalStateException("No Module in watchlist with ID = " + moduleId);
    }

    public EnrolledEntity addEnrolled(Long moduleId, HttpServletRequest request) {
        Long sessionID = getSessionID(request);
        UserEntity user = fetchUser(sessionID);
        ModuleEntity module = fetchModule(moduleId);

        checkModuleValidity(user, module);

        EnrolledEntity enrolledEntity = saveEnrollment(user, module);

        return enrolledEntity;
    }

    private UserEntity fetchUser(Long userId) {
        return userRepository.findById(userId)
                .orElseThrow(() -> new IllegalStateException("User not found with ID = " + userId));
    }

    private ModuleEntity fetchModule(Long moduleId) {
        return moduleRepository.findModuleById(moduleId);
    }

    private void checkModuleValidity(UserEntity user, ModuleEntity module) {
        if (user.getSemester() < module.getSemester()) {
            throw new IllegalStateException("You can only book modules from your semester or lower semesters");
        }

        int totalECTS = user.getEnrolledEntities().stream()
                .peek(enrolledEntity -> {
                    if (module.getId() == enrolledEntity.getModuleId()) {
                        throw new IllegalStateException("Module already booked");
                    }
                })
                .filter(enrolledEntity -> enrolledEntity.getGrade() == 0)
                .mapToInt(enrolledEntity -> fetchModule(enrolledEntity.getModuleId()).getEcts())
                .sum();

        if (totalECTS + module.getEcts() > 30) {
            throw new IllegalStateException("Exceeded maximum ECTS limit");
        }
    }

    private EnrolledEntity saveEnrollment(UserEntity user, ModuleEntity module) {
        EnrolledEntity enrolledEntity = new EnrolledEntity();
        enrolledEntity.setUserId(user.getId());
        enrolledEntity.setModuleId(module.getId());

        user.getEnrolledEntities().add(enrolledEntity);
        userRepository.save(user);

        module.getEnrolledEntities().add(enrolledEntity);
        moduleRepository.save(module);

        return enrolledRepository.save(enrolledEntity);
    }

    public Set<EnrolledEntity> getEnrolled(HttpServletRequest request) {
        Long sessionID = getSessionID(request);
        Optional<UserEntity> userOptional = userRepository.findById(sessionID);
        if (userOptional.isPresent()) {
            UserEntity user = userOptional.get();
            return user.getEnrolledEntities();
        } else {
            throw new IllegalStateException("No UserEntity found with ID = " + sessionID);
        }
    }

    public EnrolledEntity setGrade(Long moduleId, double grade, HttpServletRequest request) {
        Long sessionID = getSessionID(request);
        Optional<UserEntity> optionalUser = userRepository.findById(sessionID);
        Optional<ModuleEntity> optionalModule = moduleRepository.findById(moduleId);

        if (optionalUser.isPresent() && optionalModule.isPresent()) {

            EnrolledEntity enrolledEntity = enrolledRepository.findByUserIdAndModuleId(sessionID, moduleId);
            if (enrolledEntity != null) {
                enrolledEntity.setGrade(grade);
                enrolledRepository.save(enrolledEntity);
                return enrolledEntity;
            } else {
                throw new IllegalStateException("User is not enrolled in the module");
            }
        } else {
            throw new IllegalStateException("User or Module not found with ID = " + sessionID + ", " + moduleId);
        }
    }

    public EnrolledEntity setRating(Long moduleId, double rating, HttpServletRequest request) {
        Long sessionID = getSessionID(request);
        EnrolledEntity enrolledEntity = enrolledRepository.findByUserIdAndModuleId(sessionID, moduleId);
        if (enrolledEntity != null && enrolledEntity.getGrade() > 0) {
            enrolledEntity.setRating(rating);
            enrolledRepository.save(enrolledEntity);
            return enrolledEntity;
        } else {
            throw new IllegalStateException("User is not enrolled in the module or grade has not been set");
        }
    }

    public Set<ModuleEntity> getModulesWithoutGrade(HttpServletRequest request) {
        Long sessionID = getSessionID(request);
        Optional<UserEntity> optionalUser = userRepository.findById(sessionID);
        if (optionalUser.isPresent()) {
            UserEntity user = optionalUser.get();
            Set<ModuleEntity> enrolledModules = user.getEnrolledEntities().stream()
                    .map(enrolledEntity -> moduleRepository.findModuleById(enrolledEntity.getModuleId()))
                    .collect(Collectors.toSet());
            Set<ModuleEntity> modulesWithoutGrade = enrolledModules.stream()
                    .filter(moduleEntity -> enrolledRepository.findByUserIdAndModuleId(sessionID, moduleEntity.getId()).getGrade() == 0)
                    .collect(Collectors.toSet());
            return modulesWithoutGrade;
        } else {
            throw new IllegalStateException("No UserEntity found with ID = " + sessionID);
        }
    }

    public double calculateWeightedAverageGrade(HttpServletRequest request) {
        Long sessionID = getSessionID(request);
        Optional<UserEntity> optionalUser = userRepository.findById(sessionID);
        if (optionalUser.isPresent()) {
            UserEntity user = optionalUser.get();
            Set<EnrolledEntity> enrolledEntities = user.getEnrolledEntities();
            double totalGrade = 0;
            int totalEcts = 0;
            for (EnrolledEntity enrolledEntity : enrolledEntities) {
                ModuleEntity module = moduleRepository.findModuleById(enrolledEntity.getModuleId());
                double grade = enrolledEntity.getGrade();
                int ects = module.getEcts();
                totalGrade += grade * ects;
                totalEcts += ects;
            }
            if (totalEcts == 0) {
                return 0;
            } else {
                return totalGrade / totalEcts;
            }
        } else {
            throw new IllegalStateException("No UserEntity found with ID = " + sessionID);
        }
    }


    public ExamEntity addParticipant(Long examId, HttpServletRequest request) {
        Long sessionID = getSessionID(request);
        ExamEntity exam = getExamEntityById(examId);
        UserEntity user = getUserEntityById(sessionID);
        exam.addParticipant(user);
        return exam;
    }

    public ExamEntity getExamEntityById(Long examId) {
        return examRepository.findById(examId)
                .orElseThrow(() -> new NoSuchElementException("No exam found with id " + examId));
    }

    public UserEntity getUserEntityById(Long userId) {
        return userRepository.findById(userId)
                .orElseThrow(() -> new NoSuchElementException("No user found with id " + userId));
    }

    public UserEntity getUserEntityById(HttpServletRequest request) {
        Long sessionID = getSessionID(request);
        if (sessionID == null) {
            throw new NoSuchElementException("No sessionID cookie found in the request.");
        }

        return userRepository.findById(sessionID)
                .orElseThrow(() -> new NoSuchElementException("No user found with id " + sessionID));
    }
   /* public ResponseEntity<?> updateUser(Long userId, UserEntity userEntityDetails) {
        return userRepository.findById(userId).map(userEntity -> {
            if(userEntityDetails.getFullName() != null) userEntity.setFullName(userEntityDetails.getFullName());
            if(userEntityDetails.getEmail() != null) userEntity.setEmail(userEntityDetails.getEmail());
            // Führen Sie ähnliche Überprüfungen für andere feldspezifische Updates durch
            userRepository.save(userEntity);
            return ResponseEntity.ok(userEntity);
        }).orElse(ResponseEntity.notFound().build());
    }*/


    public Optional<UserEntity> updateUser(UserEntity userEntity, HttpServletRequest request) {
        Long sessionID = getSessionID(request);
        Optional<UserEntity> userEntity1 = userRepository.findUserById(sessionID);
        // Checking user presences and the isLoggedIn field to perform the updation.
        if (userEntity1.isPresent() && userEntity1.get().isLoggedIn()) {
            userEntity1.get().setId(userEntity1.get().getId());
            userEntity1.get().setFullName(userEntity.getFullName());
            userEntity1.get().setEmail(userEntity.getEmail());
            userEntity1.get().setUsername(userEntity.getUsername());
            userEntity1.get().setPassword(userEntity.getPassword());
            userEntity1.get().setSemester(userEntity.getSemester());
            userRepository.save(userEntity1.get());
        }
        return userEntity1;
    }
/*
    public UserEntity updateUser(Long userId, UserEntity userEntity) {
        Optional<UserEntity> user = userRepository.findUserById(userId);
        if(user.isPresent()) {
            userEntity.setId(user.get().getId());

            UserEntity saveUser = userRepository.save(userEntity);
            log.info("Die Daten des Users wurden erfolgreich geändert: {}", userId);
            return saveUser;
        }
        return null;
    }*/

    //Methode zum Zurücksetzen des Passworts
    public String resetUserPassword(ResetPasswordRequest resetPasswordRequest) {
        Optional<UserEntity> user = userRepository.findByUsername(resetPasswordRequest.getUsername());
        if (user.isPresent()) {
            user.get().setId(user.get().getId());
            user.get().setPassword(resetPasswordRequest.getPassword());
            userRepository.save(user.get());
            return "Das Passwort wurde erfolgreich aktualisiert!";
        } else {
            return "Das Passwort konnte nicht aktualisiert werden. Bitte verwenden Sie einen anderen Usernamen.";
        }
    }

    //Methode zum Hinzufügen des Profilbildes
    public String uploadProfilePicture(HttpServletRequest request, MultipartFile file) throws IOException {
        Long sessionID = getSessionID(request);
        Optional<UserEntity> user = userRepository.findById(sessionID);
        // Checking user presences and the isLoggedIn field to perform the operation.
        if (user.isPresent() && user.get().isLoggedIn()) {
            user.get().setId(user.get().getId());
            user.get().setProfilePicture(file.getBytes());
            userRepository.save(user.get());
            return "Das Profilbild wurde erfolgreich hochgeladen";
        } else {
            return "Das Profilbild konnte leider nicht hochgeladen werden. Bitte verwenden Sie ein korrektes Format (JPEG, PNG)";
        }
    }

    //Methode prüft, ob der User eingeloggt ist
    public boolean isUserLoggedIn(HttpServletRequest request) {
        Long sessionID = getSessionID(request);
        return sessionID > 0;
    }
}
