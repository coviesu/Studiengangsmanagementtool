package com.Knaben.ModuleManagement.Controller;

import com.Knaben.ModuleManagement.Entity.EnrolledEntity;
import com.Knaben.ModuleManagement.Entity.ModuleEntity;
import com.Knaben.ModuleManagement.Service.UserService;
import jakarta.servlet.http.HttpServletRequest;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Set;

@RequiredArgsConstructor
@RestController
@RequestMapping("/Enrolled")
public class EnrolledController {

    private final UserService userService;


    //Buchung der Module pro Benutzer pro Semester (max 30 ECTS)
    @PostMapping(path = "addEnrolled/{moduleId}")
    public ResponseEntity<EnrolledEntity> addEnrolled(@PathVariable Long moduleId, HttpServletRequest request) {
        return new ResponseEntity<>(userService.addEnrolled(moduleId, request), HttpStatus.CREATED);
    }

    //Anzeige aller gebuchten Module pro Benutzer
    @GetMapping(path = "getEnrolled")
    public ResponseEntity<Set<EnrolledEntity>> getEnrolled(HttpServletRequest request) {
        return new ResponseEntity<>(userService.getEnrolled(request), HttpStatus.OK);
    }

    //Filterung aller Module, für die keine Benotung vorliegt
    @GetMapping(path = "getModulesWithoutGrade")
    public ResponseEntity<Set<ModuleEntity>> getModulesWithoutGrade(HttpServletRequest request) {
        return new ResponseEntity<>(userService.getModulesWithoutGrade(request), HttpStatus.OK);
    }

    //Pro Modul: Modulbewertung nach Abschluss des Moduls
    @PostMapping(path = "setRating/{moduleId}/{rating}")
    public ResponseEntity<EnrolledEntity> setRating(@PathVariable Long moduleId, @PathVariable double rating, HttpServletRequest request) {
        return new ResponseEntity<>(userService.setRating(moduleId, rating, request), HttpStatus.OK);
    }

    //Pflegen einer Note pro Modul pro Studierender
    @PostMapping(path = "setGrade/{moduleId}/{grade}")
    public ResponseEntity<EnrolledEntity> setGrade(@PathVariable Long moduleId, @PathVariable double grade, HttpServletRequest request) {
        return new ResponseEntity<>(userService.setGrade(moduleId, grade, request), HttpStatus.OK);
    }
}
