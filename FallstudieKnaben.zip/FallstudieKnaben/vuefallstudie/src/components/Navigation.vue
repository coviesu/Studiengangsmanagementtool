<template>
  <div>
    <nav>
      <router-link v-if="isLoggedIn" to="/">Startseite</router-link> |
      <router-link v-if="isLoggedIn" to="/Module">Module</router-link> |
      <router-link v-if="isLoggedIn" to="/Noten">Notenübersicht</router-link> |
      <router-link v-if="isLoggedIn" to="/Einstellungen">Einstellungen</router-link> |
      <router-link v-if="!isLoggedIn" to="/Login">Login</router-link>
      <button v-if="isLoggedIn" @click="logout">Logout</button>
    </nav>
    <router-view/>
  </div>
</template>

<script>
export default {
  data() {
    return {
      isLoggedIn: false, // Standardmäßig ist der Benutzer nicht angemeldet
    };
  },
  methods: {
    login() {
      // Implementieren Sie hier Ihre Login-Logik
      // Setzen Sie this.isLoggedIn auf true, wenn der Login erfolgreich ist
    },
    logout() {
      // Implementieren Sie hier Ihre Logout-Logik
      // Setzen Sie this.isLoggedIn auf false, wenn der Logout erfolgreich ist
    },
  },
};
</script>

<style>
nav {
  padding: 30px;
}

nav a {
  font-weight: bold;
  color: #2c3e50;
}

nav a.router-link-exact-active {
  color: #42b983;
}
</style>
