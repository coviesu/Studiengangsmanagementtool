// store/index.js

import { createStore } from 'vuex';
import VueCookies from 'vue-cookie';
import {COOKIE_NAME} from "@/store/constants";


export default createStore({
    state: {
        isAuthenticated: !!VueCookies.get(COOKIE_NAME),
        user: null,
    },
    mutations: {
        SET_AUTHENTICATED(state, isAuthenticated) {
            state.isAuthenticated = isAuthenticated;
        },
        SET_USER(state, user) {
            state.user = user;
        },
    },
    actions: {
        login({ commit }, authToken) {
            // Hier fügst du den Login-Logik hinzu, z.B. API-Anfrage
            // Bei erfolgreicher Anmeldung:
            commit('SET_AUTHENTICATED', true);
            commit('SET_USER', authToken); // Setze den authentifizierten Benutzer
            VueCookies.set(COOKIE_NAME, authToken, { expires: '7d' }); // Cookie für 7 Tage speichern
        },
        logout({ commit }) {
            // Hier fügst du den Logout-Logik hinzu, z.B. API-Anfrage
            // Bei erfolgreicher Abmeldung:
            commit('SET_AUTHENTICATED', false);
            commit('SET_USER', null);
            VueCookies.delete(COOKIE_NAME); // Entferne das Cookie
        },
    },
    getters: {
        isAuthenticated: (state) => state.isAuthenticated,
        user: (state) => state.user,
    },
});
