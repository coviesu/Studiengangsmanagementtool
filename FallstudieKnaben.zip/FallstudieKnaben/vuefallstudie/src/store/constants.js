export const COOKIE_NAME = 'authToken';
