<template>
  <div id="app">
    <nav v-if="isAuthenticated" class="taskbar">
      <div class="taskbar-left">
        <router-link to="/Startseite" class="taskbar-item">Startseite</router-link>
        <!-- Dropdown-Menü für Module -->
        <router-link to="/Module" class="dropdown">
          <button class="taskbar-item dropbtn">Module</button>
          <div class="dropdown-content">
            <router-link to="/Module/Merkliste">Merkliste</router-link>
            <router-link to="/Module/GebuchteModule">Gebuchte Module</router-link>
          </div>
        </router-link>
        <router-link to="/Noten" class="taskbar-item">Notenübersicht</router-link>
        <router-link to="/Einstellungen" class="taskbar-item">Einstellungen</router-link>
      </div>
      <div v-if="isAuthenticated" class="logout-container">
        <button @click="logout" class="logout-button">Logout</button>
      </div>
    </nav>
    <router-view/>
  </div>
</template>

<style>
#app {
  font-family: 'SF Pro Text', 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
  text-align: center;
}

.taskbar {
  background-color: #0070c9; /* Blaue Hintergrundfarbe der Taskleiste */
  padding: 10px 20px; /* Innenabstand der Taskleiste */
  display: flex;
  justify-content: space-between; /* Elemente gleichmäßig verteilen */
  align-items: center; /* Vertikal zentrieren */
}

.taskbar-left {
  display: flex;
}

.taskbar-item {
  color: #fff; /* Textfarbe der Taskleisten-Elemente */
  text-decoration: none; /* Unterstreichungen entfernen */
  padding: 10px 20px; /* Innenabstand der Taskleisten-Elemente */
  transition: background-color 0.3s; /* Übergangseffekt */
}

.taskbar-item:hover {
  background-color: #005bac; /* Dunkleres Blau ändern, wenn Maus darüber */
}

.logout-container {
  margin-right: 20px; /* Abstand zum Rand */
}

.logout-button {
  background-color: #fff; /* Weiß für Logout-Button */
  color: #0070c9; /* Blau für Text des Logout-Buttons */
  border: none;
  padding: 8px 16px; /* Innenabstand des Logout-Buttons */
  cursor: pointer;
  border-radius: 4px; /* Abgerundete Ecken */
  transition: background-color 0.3s; /* Übergangseffekt */
}

.logout-button:hover {
  background-color: #e5e5e5; /* Helleres Grau ändern, wenn Maus darüber */
}
.dropdown {
  display: inline-block;
  position: relative;
}

.dropbtn {
  background-color: #0070c9;
  color: white;
  padding: 10px;
  font-size: 16px;
  border: none;
  cursor: pointer;
}

.dropdown-content {
  display: none;
  position: absolute;
  background-color: #f9f9f9;
  min-width: 160px;
  box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
  z-index: 1;
}

.dropdown-content a {
  color: black;
  padding: 12px 16px;
  text-decoration: none;
  display: block;
}

.dropdown-content a:hover {background-color: #f1f1f1;}

.dropdown:hover .dropdown-content {display: block;}

.dropdown:hover .dropbtn {background-color: #005bac;}
</style>



<script>
import {computed} from "vue";
import {useStore} from 'vuex'
export default {
  name: 'App',
  setup() {
    const store = useStore();
    const isAuthenticated = computed(() => store.state.isAuthenticated);

    // Hier können Sie `isAuthenticated` verwenden, z.B. für die Navigation

    return {
      isAuthenticated,
    };},

  methods:{
    logout() {
      this.$store.dispatch('logout');
      this.$router.push('/Login');
    }
  }
}

</script>