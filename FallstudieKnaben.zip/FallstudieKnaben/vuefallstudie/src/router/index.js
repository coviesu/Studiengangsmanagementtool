// router/index.js

import { createRouter, createWebHistory } from 'vue-router';
import StartseiteVUe from "@/views/StartseiteVUe/StartseiteVUe";
import LoginView from "@/views/LoginView/LoginView";
import ModuleView from "@/views/ModuleView/ModuleView";
import EinstellungenVue from "@/views/EinstellungenView/EinstellungenVue";
import NotenView from "@/views/NotenView/NotenView";
import store from "@/store";
import Merkliste from "@/views/ModuleView/MerklisteView/MerklisteView"
import GebuchteModuleView from "@/views/ModuleView/GebuchteModuleView/GebuchteModuleView"


const routes = [

  {
    path: '/',
    redirect: '/login'  // Umleitung zur Login-Seite für die Basis-URL
  },
  {
    path: '/Login',
    name: 'Login',
    component: LoginView,
    meta: { requiresAuth: false }
  },
  {
    path: '/Startseite',
    name: 'Startseite',
    component: StartseiteVUe,
    meta: { requiresAuth: true }
  },
  {
    path: '/Noten',
    name: 'Noten',
    component: NotenView,
    meta: { requiresAuth: true }
  },
  {
    path: '/Module',
    name: 'Module',
    component: ModuleView,
    meta: { requiresAuth: true }
  },
  {path:'/Module/Merkliste',
  name:'Merkliste',
  component: Merkliste,
    meta: { requiresAuth: true }
  },
  {path:'/Module/GebuchteModule',
    name:'GebuchteModule',
    component: GebuchteModuleView,
    meta: { requiresAuth: true }
  },


  {
    path: '/Einstellungen',
    name: 'Einstellungen',
    component: EinstellungenVue,
    meta: { requiresAuth: true }
  },
];

const router = createRouter({
  history: createWebHistory(process.env.BASE_URL),
  routes
});

router.beforeEach((to, from, next) => {
  // Überprüfe, ob die Seite eine Authentifizierung erfordert
  if (to.meta.requiresAuth && !store.getters.isAuthenticated) {
    // Der Benutzer ist nicht authentifiziert --> Umleitung zur Login-Seite
    next('/Login');
  } else {
    next();
  }
});

export default router;
