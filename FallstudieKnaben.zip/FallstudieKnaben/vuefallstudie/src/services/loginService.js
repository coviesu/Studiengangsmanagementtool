import axios from "axios";

const LOGIN_BASE_URL = "http://localhost:8080";

axios.defaults.withCredentials = true;

class LoginService {
    loginUser(username, password) {
        return axios.post(`${LOGIN_BASE_URL}/login?username=${username}&password=${password}`)
            .then(response => {
                if (response.status === 200) {
                    // Erfolgreich angemeldet, setze den x-user-id Cookie
                    const user = response.data; // Angenommen, dass die UserEntity als JSON zurückgegeben wird
                    if (user && user.id) {
                        this.setUserIdCookie(user.id);
                    }
                }
                return response;
            });
    }

    logOutUser() {
        return axios.post(`${LOGIN_BASE_URL}/logout`)
            .then(() => {
                this.removeUserIdCookie();
            });
    }

    setUserIdCookie(userId) {
        document.cookie = `x-user-id=${userId}; path=/`;
    }

    removeUserIdCookie() {
        document.cookie = "x-user-id=; expires=Thu, 01 Jan 1970 00:00:00 GMT; path=/";
    }
}

export default new LoginService();
