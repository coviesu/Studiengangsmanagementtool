import axios from "axios";

const BASE_URL = "http://localhost:8080/Enrolled";

axios.defaults.withCredentials = true;


class enrolledService{

    getGebuchteModuleAnzeigen(){
        return axios.get(`${BASE_URL}/getEnrolled`)
    }

}

export default new enrolledService();
