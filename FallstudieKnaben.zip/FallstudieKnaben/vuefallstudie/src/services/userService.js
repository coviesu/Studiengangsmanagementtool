import axios from "axios";

const BASE_URL = "http://localhost:8080";

class userService{
    registerUser (newUser){
        return axios.post(`${BASE_URL}/UserEntity/addUser`,newUser)
    }

    merklisteAddUser(moduleId){
        return axios.post(`${BASE_URL}/UserEntity/addToWatchlist/${moduleId}`)
    }
    removeFromWatchlist(moduleId){
        return axios.post(`${BASE_URL}/UserEntity/removeFromWatchlist/${moduleId}`)
    }

    moduleBuchenUser(moduleId){
        return axios.post(`${BASE_URL}/Enrolled/addEnrolled/${moduleId}`)
    }

    getWatchlist(){
        return axios.get(`${BASE_URL}/UserEntity/getWatchList`)
    }


    profilBildUpload(profilePictureAsBytes,username) {
        return axios.post(`${BASE_URL}/UserEntity/${username}/profilBildUpload`, profilePictureAsBytes, {
            headers: {
                'Content-Type': 'application/octet-stream'
            }
        })
    }

    updateUser(UpdateData){
        return axios.post(`${BASE_URL}/UserEntity/updateUser`,UpdateData)
    }
    updatePasswort(neuespassword){
        return axios.post(`${BASE_URL}/UserEntity/updateUser`,neuespassword)
    }
}

export default new userService();