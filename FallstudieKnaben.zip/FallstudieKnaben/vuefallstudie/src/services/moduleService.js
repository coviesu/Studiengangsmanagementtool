import axios from "axios";

const MODULE_BASE_URL = "http://localhost:8080/modul";

class moduleService {
        getModule() {
                return axios.get(MODULE_BASE_URL);
        }

        createModule(moduleData) {
                return axios.post(`${MODULE_BASE_URL}/create`, moduleData);
        }

        deleteModule(moduleId) {
                return axios.delete(`${MODULE_BASE_URL}/${moduleId}`);
        }

}


export default new moduleService();
