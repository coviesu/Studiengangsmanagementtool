import UserService from "@/services/userService";

export function buttonEinschreibenClicked(moduleId) {
    UserService.moduleBuchenUser(moduleId)
        .then(response => {
            console.log("Modul wurde erfolgreich gebucht", moduleId);
            console.log("Erfolgreiche Antwort vom Backend:", response);
        })
        .catch(error => {
            console.log("Die ModulID des angeklickten Moduls ist:", moduleId);
            console.error("Fehler beim Hinzufügen zur Merkliste", error);
        });

    console.log("Button Einschreiben wurde geklickt");

}