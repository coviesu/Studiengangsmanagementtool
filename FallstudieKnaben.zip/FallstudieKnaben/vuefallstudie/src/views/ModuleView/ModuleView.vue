<template>

  <div>
    <h1>Module</h1>
    <div class="buttons-oben-Modulliste">
      <button class="button1" @click="buttonAllesAuswählenClicked">Alles Auswählen</button>
      <button class="button1" @click="buttonGebuchteModule">Gebuchte Module</button>
      <button class="button1" @click="buttonsMerklisteClicked">Merkliste</button>
    </div>

    <div class="module-list">
      <ul>
        <li v-for="module in modules" :key="module.id">
          <div class="module-wrapper">

            <div class="module-info">
              <input type="checkbox" v-model="selectedModules" :value="module.id">

              <label class="module-name" @click="toggleDetails(module)">{{ module.name }}</label>
              <div class="buttons-container-oben">
            <button class="buttons-modulName" @click="buttonEinschreibenClicked(module.id)">Einschreiben</button>
            <button class="buttons-modulName" @click="buttonMerklisteAdd(module.id)">Zu Merkliste hinzufügen</button>
              </div>
            </div>

            <transition name="fade">
              <div v-if="selectedModule && selectedModule.id === module.id" class="module-details-box">
                <div class="module-details">
                  <p><strong>Beschreibung:</strong> {{ module.description }}</p>
                  <p><strong>ECTS:</strong> {{ module.ects }}</p>
                  <p><strong>Dozent:</strong> {{ module.lecturer }}</p>
                  <p><strong>Fachbereich:</strong> {{ module.department }}</p>
                  <p><strong>Regulärer Stundenplan:</strong> {{ module.regularSchedule }}</p>
                  <p><strong>Literaturempfehlung:</strong> {{ module.literatureRecommendation }}</p>
                  <p><strong>Semester:</strong> {{ module.semester }}</p>
                  <p><strong>Eingeschriebene Studenten:</strong>{{module.enrolledEntities}}</p>
                </div>
              </div>
            </transition>
          </div>
        </li>
      </ul>
    </div>
    <button class="buttons-unten-löschen" @click="buttonDelete">Löschen</button>
    <button class="button-unten-erstellen" @click="openPopup">Erstellen</button>

    <!-- PopupFenster Modul erstellen-->

    <div v-if="popupModulErstellen" class ="popup">
      <div class="popup-content">
       <button class="back-button" @click="closePopup">Zurück</button>

        <!--- Inhalt des PopupFenster-->
        <h2>Popup Inhalt</h2>

        <form>
          <label for="moduleName">Modulname:</label>
          <input type="text" id="moduleName" name="moduleName" v-model="moduleName" required>

          <label for="ects">ECTS:</label>
          <input type="number" id="ects" name="ects" v-model="ects" required min="1">

          <label for="lecturer">Dozent:</label>
          <input type="text" id="lecturer" name="lecturer" v-model="lecturer" required>

          <label for="department">Fachbereich:</label>
          <input type="text" id="department" name="department" v-model="department" required>

          <label for="description">Modulbeschreibung:</label>
          <textarea id="description" name="description" rows="4" v-model="description" required></textarea>

          <label for="literature">Literatur:</label>
          <textarea id="literature" name="literature" rows="4" v-model="literature" required></textarea>

          <label for="regularSchedule">Regulärer Stundenplan:</label>
          <textarea id="regularSchedule" name="regularSchedule" rows="4" v-model="regularSchedule" required></textarea>

          <label for="semester">Semester:</label>
          <input type="number" id="semester" name="semester" v-model="semester" required min="1">

          <!--  <label for="examDate1">1. Klausurtermin:</label>
            <input type="date" id="examDate" name="examDate" required>

            <label for="examDate2">2. Klausurtermin:</label>
            <input type="date" id="examDate" name="examDate" required>
  -->
        </form>

        <!--- Speichern Button-->
      <button class ="save-button" @click="saveAndClosePopup">speichern</button>
      </div>

    </div>
  </div>
</template>

<script src="./ModuleView.vue.js"></script>
<style src="./ModuleView.vue.css" scoped></style>
