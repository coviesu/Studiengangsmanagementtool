import enrolledService from "@/services/enrolledService";


export default {
    data(){
        return {
            gebuchteList: [],
            selectedModule: [],
            moduleId:null,
            modules:[],
        }
    },

    created() {
      this.fetchGebuchteModule()
    },

    methods: {
       async fetchGebuchteModule() {
           try {
               const response = await enrolledService.getGebuchteModuleAnzeigen()
               this.gebuchteList = response.data;
               console.log("Die Gebuchten Module des Users:", this.gebuchteList)
           } catch (error){
               console.error("Fehler beim Abrufen der gebuchten Module",error)
           }
        },
        toggleDetails(module) {
            if (this.selectedModule && this.selectedModule.id === module.id) {
                this.selectedModule = null;
            } else {
                this.selectedModule = module;
            }
        },
    }

}