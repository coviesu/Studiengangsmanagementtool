<template>

  <div>
    <div class ="page-title">
      <router-link to="/Module" class="back-arrow">Zurück</router-link>
    </div> <h2> Deine Gebuchten Module</h2>  </div>

  <div class="module-list">
    <ul>
      <li v-for="module in gebuchteList" :key="module.id">
        <label class="module-name" @click="toggleDetails(module)">{{ module.name }}</label>
        <div class="buttons-container-oben">
          <button class="buttons-modulName" @click="buttonKlausurtermin">Klausurtermin</button>
        </div>

        <transition name="fade">
          <div v-if="selectedModule && selectedModule.id === module.id" class="module-details-box">
            <div class="module-details">
              <p><strong>Beschreibung:</strong> {{ module.description }}</p>
              <p><strong>ECTS:</strong> {{ module.ects }}</p>
              <p><strong>Dozent:</strong> {{ module.lecturer }}</p>
              <p><strong>Fachbereich:</strong> {{ module.department }}</p>
              <p><strong>Regulärer Stundenplan:</strong> {{ module.regularSchedule }}</p>
              <p><strong>Literaturempfehlung:</strong> {{ module.literatureRecommendation }}</p>
              <p><strong>Semester:</strong> {{ module.semester }}</p>
              <p><strong>Eingeschriebene Studenten:</strong> {{ module.enrolledEntities }}</p>
            </div>
          </div>
        </transition>
      </li>
    </ul>
  </div>

</template>

<script src="./GebuchteModule.js"></script>
<style src="../ModuleView.vue.css" scoped></style>