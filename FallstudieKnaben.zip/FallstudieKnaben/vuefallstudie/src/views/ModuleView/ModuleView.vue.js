import moduleService from "@/services/moduleService";
import UserService from "@/services/userService";
import enrolledService from "@/services/enrolledService";
import {buttonEinschreibenClicked} from "@/views/ModuleView/Funktionen";

export default {
    data() {
        return {
            modules: [],
            selectedModule: null,
            popupModulErstellen : false, //damit das PopupFenster erst beim klicken sich öffnet
            selectedModules:[],
            moduleIds:null,
            modulId:0,
            moduleId: null,
            watchlist:[],
            watchlistModules:[],

            //Erstellen Formular
            moduleName:"",
            ects: "",
            lecturer:"",
            department: "",
            description:"",
            literature:"",
            regularSchedule:"",
            enrolledEntities: "",
            //examDate1:"",
            //examDate2:""
            semester:"",
        };
    },
    created() {
        this.fetchModules();
    },
    methods: {
        fetchModules() {
            moduleService.getModule()
                .then(response => {
                    this.modules = response.data;
                })
                .catch(error => {
                    console.error("Fehler beim Abrufen der Module:", error);
                });
        },
        toggleDetails(module) {
            if (this.selectedModule && this.selectedModule.id === module.id) {
                this.selectedModule = null;
            } else {
                this.selectedModule = module;
            }
        },
        buttonEinschreibenClicked,

        buttonMerklisteAdd(moduleId) {
            if (!isNaN(moduleId)) {
                console.log("Button Merkliste wurde geklickt für Modul mit ID:", moduleId);

                UserService.merklisteAddUser(moduleId)
                    .then(response => {
                        console.log("Modul wurde der Merkliste hinzugefügt", moduleId);
                        // Hier kannst du weitere Aktionen ausführen, z.B. eine Benachrichtigung anzeigen
                        console.log("Erfolgreiche Antwort vom Backend:", response);

                    })
                    .catch(error => {
                        console.log("Die ModulID des angeklickten Moduls ist:", modulId);
                        console.error("Fehler beim Hinzufügen zur Merkliste", error);
                        // Hier kannst du einen Fehler behandeln, z.B. eine Fehlermeldung anzeigen
                    });

                console.log("Button Merkliste hinzufügen wurde geklickt");
            } else {
                console.error("Ungültiger Wert für Modul ID:", modulId);
            }
        },


        buttonAllesAuswählenClicked() {
            if (this.selectedModules.length === this.modules.length) {
                // Wenn alle bereits ausgewählt sind, dann alles abwählen
                this.selectedModules = [];
            } else {
                // Sonst alles auswählen
                this.selectedModules = this.modules.map(module => module.id);
                console.log("Butten AllesAuswählen wurde geklickt")
            }

        },


        buttonGebuchteModule(){
            this.$router.push({name:"GebuchteModule"})
            console.log("Button für Gebuchte Module wurde geklickt")

        },
        buttonsMerklisteClicked() {
        this.$router.push({name:"Merkliste"})
            },

        openPopup() {
            this.popupModulErstellen = true;
        },
        closePopup() {
            this.popupModulErstellen = false;

        },



        buttonDelete() {
            console.log("Ausgewählte Module:", this.selectedModules);


            if (this.selectedModules.length === 0) {
                alert("Bitte wähle mindestens ein Modul zum Löschen aus.");
                return;
            }
            this.selectedModules.forEach(moduleId =>{
            moduleService.deleteModule(moduleId)
                .then(response => {
                    console.log("Ausgewählte Module gelöscht:", response.data);
                    this.fetchModules(); // Aktualisiere die Modulliste
                    this.selectedModules = []; // Setze die ausgewählten Module zurück
                })
                .catch(error => {
                    console.log(moduleId)
                    console.error("Fehler beim Löschen der Module:", error);
                });
        })
        },



        saveAndClosePopup() {
            if (!this.validateForm()) {
                return;
            }

            const data = {
                name: this.moduleName,
                ects: this.ects,
                lecturer: this.lecturer,
                department: this.department,
                description: this.description,
                literatureRecommendation: this.literature,
                regularSchedule: this.regularSchedule,
                semester: this.semester
            }


            moduleService.createModule(data)
                .then(response => {

                                     this.modules.push(response.data)

                    this.moduleName = "";
                    this.ects = "";
                    this.lecturer = "";
                    this.department = "";
                    this.description = "";
                    this.literature = "";
                    this.regularSchedule = "",
                        this.semester = "",

                        this.fetchModules();
                    this.closePopup();

                })
                .catch(error => {
                    console.error("Fehler beim Erstellen des Moduls:", error)
                })
        },
        validateForm() {
            if (this.moduleName.trim() === '' ||
                this.ects <= 0 ||
                this.lecturer.trim() === '' ||
                this.department.trim() === '' ||
                this.description.trim() === '' ||
                this.literature.trim() === '' ||
                this.regularSchedule.trim() === '' ||
                this.semester <= 0) {
                // Hier kannst du auch benutzerfreundliche Fehlermeldungen setzen
                alert('Bitte füllen Sie alle Felder aus.');
                return false;
            }
            return true;
        }
    }
};