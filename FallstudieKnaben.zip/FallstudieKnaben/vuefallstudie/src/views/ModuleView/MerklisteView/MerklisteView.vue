<template>
  <div>

    <div class="page-title">
      <!-- Pfeil zum Zurücknavigieren -->
      <router-link to="/Module" class="back-arrow">Zurück</router-link>

    </div><h2> Deine Merkliste</h2></div>


    <div class="module-list">
      <ul>
        <li v-for="module in watchlist" :key="module.id">
          <div class="module-wrapper">

            <div class="module-info">
              <input type="checkbox" v-model="selectedModules" :value="module.id">

              <label class="module-name" @click="toggleDetails(module)">{{ module.name }}</label>
              <div class="buttons-container-oben">
                <button class="buttons-modulName" @click="buttonEinschreibenClicked(module.id)">Einschreiben</button>
                <button class="buttons-modulName" @click="buttonMerklisteDelete(module.id)">Von Merkliste entfernen</button>
              </div>
            </div>

            <transition name="fade">
              <div v-if="selectedModule && selectedModule.id === module.id" class="module-details-box">
                <div class="module-details">
                  <p><strong>Beschreibung:</strong> {{ module.description }}</p>
                  <p><strong>ECTS:</strong> {{ module.ects }}</p>
                  <p><strong>Dozent:</strong> {{ module.lecturer }}</p>
                  <p><strong>Fachbereich:</strong> {{ module.department }}</p>
                  <p><strong>Regulärer Stundenplan:</strong> {{ module.regularSchedule }}</p>
                  <p><strong>Literaturempfehlung:</strong> {{ module.literatureRecommendation }}</p>
                  <p><strong>Semester:</strong> {{ module.semester }}</p>
                  <p><strong>Eingeschriebene Studenten:</strong> {{ module.enrolledEntities }}</p>
                </div>
              </div>
            </transition>
          </div>
        </li>
      </ul>
    </div>
  <button class="buttons-unten-löschen" @click="buttonDelete">Löschen</button>
</template>

<script src="./Merkliste.vue.js"></script>
<style src="../ModuleView.vue.css" scoped></style>