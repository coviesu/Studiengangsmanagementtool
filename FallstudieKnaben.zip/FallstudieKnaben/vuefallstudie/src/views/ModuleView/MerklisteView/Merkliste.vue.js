import UserService from "@/services/userService";
import {buttonEinschreibenClicked} from "@/views/ModuleView/Funktionen";
import moduleService from "@/services/moduleService";

export default {
    data() {
        return {
            watchlist: [],
            selectedModule: null,
            modules:[],
            selectedModules:[],
            moduleId: null,
        };
    },
    created() {
        this.fetchWatchlist();
    },
    methods: {
        async fetchWatchlist() {
            try {
                const response = await UserService.getWatchlist();
                this.watchlist = response.data;
                console.log("Merkliste des Benutzers:", this.watchlist);
            } catch (error) {
                console.error("Fehler beim Abrufen der Merkliste:", error);
                // Führe hier geeignete Fehlerbehandlung durch, z.B. Anzeigen einer Fehlermeldung
            }
        },
        toggleDetails(module) {
            if (this.selectedModule && this.selectedModule.id === module.id) {
                this.selectedModule = null;
            } else {
                this.selectedModule = module;
            }
        },
        buttonEinschreibenClicked,



        buttonDelete() {
            console.log("Ausgewählte Module:", this.selectedModules);


            if (this.selectedModules.length === 0) {
                alert("Bitte wähle mindestens ein Modul zum Löschen aus.");
                return;
            }
            this.selectedModules.forEach(moduleId =>{
                moduleService.deleteModule(moduleId)
                    .then(response => {
                        console.log("Ausgewählte Module gelöscht:", response.data);
                        this.fetchModules(); // Aktualisiere die Modulliste
                        this.selectedModules = []; // Setze die ausgewählten Module zurück
                    })
                    .catch(error => {
                        console.log(moduleId)
                        console.error("Fehler beim Löschen der Module:", error);
                    });
            })
        },
        buttonMerklisteDelete(moduleId) {
            UserService.removeFromWatchlist(moduleId)
                .then(response => {
                    console.log("Modul wurde von der Watchlist gelöscht",moduleId);
                    console.log("Erfolreiche Antwort vom Backend",response)
                    this.fetchWatchlist();

                })
                .catch(error => {
                    console.log("Die ModulID des angeklickten Moduls ist:", moduleId);
                    console.error("Fehler beim Hinzufügen zur Merkliste", error);
        })
    }
}
}