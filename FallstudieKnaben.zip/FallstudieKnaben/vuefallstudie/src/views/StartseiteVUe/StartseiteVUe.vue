<template>
  <div class="container">
    <h1>Willkommen zum Studentenmanagementtool</h1>
  </div>
</template>

<style>
.container {
  background-image: url("@/assets/Startseite.jpeg");
  background-size: cover;
  background-position: center;
  height: 90vh; /* Hier wird die Höhe des Containers auf die Höhe des Bildschirms gesetzt */
}
</style>
