// @ is an alias to /src
import HelloWorld from '@/components/HelloWorld.vue'

export default {
    name: 'HomeView',
    components: {
        HelloWorld
    }
    data() {
        return {
          Startseite:'@/assets/Startseite.jpeg'
        };
      }
};