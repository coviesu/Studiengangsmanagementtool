import loginService from "@/services/loginService"; // Import der LoginService Klasse
import userService from "@/services/userService";
import { mapActions } from 'vuex';

export default {
    name: "LoginView",

    data() {
        return {
            username: "",
            password: "",
            newUsername: "",
            newEmail: "",
            newPassword: "",
            confirmPassword: "",
            newFullname:"",

            forgotPasswordEmail: "",
            sendResetPasswordEmail: "",
            registerVisible: "",
            forgotPasswordVisible: "",
            loginVisible: "",
        };
    },
    methods: {
        ...mapActions(['login']), // Hier importieren Sie `login` aus dem Vuex Store

        Anmeldebutton() {
            const username = this.username;
            const password = this.password;

            loginService.loginUser(username, password)
                .then(response => {
                    this.username = "";
                    this.password = "";

                    console.log("Erfolgreich angemeldet", response.data.id,response.data.username);
                    localStorage.setItem('userID',response.data.id)
                    localStorage.setItem('username',response.data.username)
                    console.log('Username',localStorage.getItem('username'))

                    // Beispiel: Weiterleitung nach erfolgreicher Anmeldung zur Startseite
                    this.$router.push('/Startseite');
                })
                .catch(error => {
                    alert("Username oder Passwort sind falsch. Bitte überprüfen Sie Ihre Angaben");

                    this.username = "";
                    this.password = "";
                });
        },

        register() {
            // Implementiere deine Registrierungslogik hier
        },

        Logoutbutton() {
            loginService.logOutUser().then(response => {
                this.$store.dispatch('logout'); // Dispatch der Logout-Aktion im Store
                this.$router.push('/'); // Weiterleitung zur Loginseite
                console.log("Erfolgreich abgemeldet", response.data);
            });
        },

        showLoginForm() {
            this.registerVisible = false;
            this.forgotPasswordVisible = false;
        },

        showRegisterForm() {
            this.loginVisible = false;
            this.registerVisible = true;
            this.forgotPasswordVisible = false;
        },

        showForgotPasswordForm() {
            this.loginVisible = false;
            this.registerVisible = false;
            this.forgotPasswordVisible = true;
        },

        registrieren() {
            if (this.newPassword !== this.confirmPassword) {
                alert("Die Passwörter stimmen nicht überein. Bitte überprüfen Sie ihre Eingabe");
                return;
            }
            if (this.newUsername, this.newEmail,this.newPassword,this.confirmPassword == ""){
                alert ("Bitte geben Ihre Daten ein")
                return;
            }

            const newUser = {
                username: this.newUsername,
                email: this.newEmail,
                password: this.newPassword,
                fullName:this.newFullname,
            };

            console.log("Daten, die an den Server gesendet werden:", newUser);

            userService.registerUser(newUser)
                .then(response => {
                    alert("Registrierung erfolgreich! Sie können sich jetzt anmelden.");

                    // Zurücksetzen der Eingabefelder
                    this.newUsername = "";
                    this.newEmail = "";
                    this.newPassword = "";
                    this.confirmPassword = "";
                    this.newFullname="";

                    this.loginVisible = true;
                    this.registerVisible = false;
                    this.forgotPasswordVisible = false;


                })
                .catch(error => {
                    console.error("Fehler bei der Registrierung:", error);
                    alert("Fehler bei der Registrierung. Bitte versuchen Sie es erneut.");
                });
        }
    }
};
