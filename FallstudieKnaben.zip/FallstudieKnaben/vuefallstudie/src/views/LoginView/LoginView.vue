<template>
  <div id="app">
    <div class="login-container" v-show="!registerVisible && !forgotPasswordVisible">
      <h2>Anmeldung</h2>
    <form class="login-form" @submit.prevent="login">
      <div class="form-input">
        <input v-model="username" placeholder="Benutzername" required type="text">
      </div>
      <div class="form-input">
        <input v-model="password" placeholder="Passwort" required type="password">
      </div>
      <button class ="save-button" @click="Anmeldebutton">Anmelden</button>




    </form>
    <div class="additional-links">
      <a href="#" @click="showRegisterForm">Registrieren</a>
      <a href="#" @click="showForgotPasswordForm">Passwort vergessen?</a>
    </div>
  </div>

  <div class="login-container" style="display: none;" v-show="registerVisible">
    <h2>Registrierung</h2>
    <form class="register-form" @submit.prevent="register">
      <div class="form-input">
        <input v-model="newUsername" placeholder="Benutzername" required type="text">
      </div>
      <div class="form-input">
        <input v-model="newEmail" placeholder="E-Mail" required type="email">
      </div>
      <div class="form-input">
        <input v-model="newFullname" placeholder="Kompletter Name" required type="text">
      </div>
      <div class="form-input">
        <input v-model="newPassword" placeholder="Passwort" required type="password">
      </div>
      <div class="form-input">
        <input v-model="confirmPassword" placeholder="Passwort bestätigen" required type="password">
      </div>
      <button class ="Registrieren-button" @click="registrieren">Registrieren</button>

    </form>
    <div class="additional-links">
      <a href="#" @click="showLoginForm">Zurück zur Anmeldung</a>
    </div>
  </div>

  <div class="login-container" style="display: none;" v-show="forgotPasswordVisible">
    <h2>Passwort vergessen?</h2>
    <form class="forgot-password-form" @submit.prevent="sendResetPasswordEmail">
      <div class="form-input">
        <input v-model="forgotPasswordEmail" placeholder="E-Mail" required type="email">
      </div>
      <button class="form-button" type="submit">Passwort zurücksetzen</button>
    </form>
    <div class="additional-links">
      <a href="#" @click="showLoginForm">Zurück zur Anmeldung</a>
    </div>
  </div>
  </div>

  <button class ="logut-button" @click="Logoutbutton">Logout</button>

</template>

<script src="./LoginView.vue.js"></script>
<style src="./LoginView.vue.css" scoped></style>
