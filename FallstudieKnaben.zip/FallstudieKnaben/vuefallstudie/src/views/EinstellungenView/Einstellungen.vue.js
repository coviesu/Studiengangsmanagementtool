import UserService from "@/services/userService";
import userService from "@/services/userService";


export default {
  data() {
    return {
      newUserName: "",
      newEmail: "",
      newLastName: "",
      username: "",
      fullName: "",
      email: "",
      profilePicture: null,
      profilePictureUrl: "",

      oldPassword: "",
      newPassword: "",
      confirmNewPassword: "",
    };
  },
  methods: {
    updateProfilePicture(event) {
      const file = event.target.files[0];
      if (!file) return;

      this.profilePicture = file;
      this.profilePictureUrl = URL.createObjectURL(file);
    },
    uploadProfilePicture() {
      if (!this.profilePicture) {
        alert('Bitte wählen Sie zuerst ein Bild aus.');
        return;
      }

      const reader = new FileReader();
      reader.onload = () => {
        const profilePictureAsBytes = new Uint8Array(reader.result);
        userService.profilBildUpload(profilePictureAsBytes, username)
            .then(response => {
              alert('Profilbild erfolgreich hochgeladen.');
              // Hier kannst du weitermachen, z.B. den Benutzer über den Erfolg informieren
            })
            .catch(error => {
              console.error('Fehler beim Hochladen des Profilbildes:', error);
              alert('Fehler beim Hochladen des Profilbildes. Bitte versuchen Sie es erneut.');
            });
      };
      reader.readAsArrayBuffer(this.profilePicture);
    },


    änderungenSpeichernClick() {

      const UpdateData = {
        username: this.newUserName,
        fullName: this.newLastName,
        email: this.newEmail,
      }
      console.log("Daten die an Server gesendet werden", UpdateData)

      userService.updateUser(UpdateData)
          .then(response => {
            alert("Userdaten wurden geupdatet")
            console.log(response)

          })
          .catch(error => {
            console.error("Fehler beim Aktualisieren", error)
            console.log("DAs wurde gesendet", UpdateData)
          })


    },
    passwortAendernClick() {

      if (this.newPassword !== this.confirmNewPassword) {
        alert("Die Passwörter stimmen nicht überein. Bitte überprüfen Sie ihre Eingabe");
        return;
      }
      if (this.oldPassword, this.newPassword, this.confirmNewPassword == "") {
        alert("Bitte geben Ihre Daten ein")
        return;
      }
      const neuespassword ={
        password : this.newPassword
          }
      ;
      console.log("Daten, die an den Server gesendet werden:", this.confirmNewPassword, this.newPassword);

      userService.updatePasswort(neuespassword)
          .then(response => {
            alert("Passwort ändern war erfolreich")
          })
          .catch(error => {
            console.error("Fehler bei der Registrierung:", error);
            alert("Fehler bei der Registrierung. Bitte versuchen Sie es erneut.");


          })

    }
  }
}
