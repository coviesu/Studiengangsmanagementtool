<template>
  <div class="settings-container">
    <h2>Einstellungen</h2>

    <div class="settings-form">
      <div class="profile-pic">
        <h3>Profilbild</h3>
        <input type="file" id="profile-picture" @change="updateProfilePicture" accept="image/*">
        <div class="profile-picture" v-if="profilePicture">
          <img :src="profilePictureUrl" alt="Profilbildvorschau">
        </div>
        <button class="button1" @click="uploadProfilePicture">Profilbild hochladen</button>
      </div>

      <div class="personal-info">
        <h3>Persönliche Informationen</h3>
        <input v-model="newUserName" type="text" placeholder="Userame" required>
        <input v-model="newLastName" type="text" placeholder="Nachname" required>
        <input v-model="newEmail" type="email" placeholder="E-Mail" required>
        <button class="button1" @click="änderungenSpeichernClick">Änderungen Speichern</button>
      </div>

      <div class="password-change">
        <h3>Passwort ändern</h3>
        <input v-model="oldPassword" type="password" placeholder="Altes Passwort" required>
        <input v-model="newPassword" type="password" placeholder="Neues Passwort" required>
        <input v-model="confirmNewPassword" type="password" placeholder="Neues Passwort bestätigen" required>
        <button class="button1" @click="passwortAendernClick">Passwort ändern</button>
      </div>
    </div>
  </div>
</template>

<script src="./Einstellungen.vue.js"></script>


<style src="./Einstellungen.vue.css" scoped></style>
