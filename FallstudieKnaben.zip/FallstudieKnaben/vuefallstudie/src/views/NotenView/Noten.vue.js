export default {


    data() {
        return {
            modules: [
                {
                    Modul: 'Modul 1',
                    Datum: '27.02.24',
                    Credits: '3 ETCs',
                    Note: '2,0',
                    Status: 'Abgeschlossen',
                    Einsicht: '_'
                },
                {
                    Modul: 'Modul 2',
                    Datum: '25.02.24',
                    Credits: '3 ETCs',
                    Note: '2,3',
                    Status: '',
                    Einsicht: ''
                },
                {
                    Modul: 'Modul 3',
                    Datum: '29.02.24',
                    Credits: '3 ETCs',
                    Note: '',
                    Status: 'Abgeschlossen',
                    Einsicht: ''
                }
            ]
        };
    }
};
