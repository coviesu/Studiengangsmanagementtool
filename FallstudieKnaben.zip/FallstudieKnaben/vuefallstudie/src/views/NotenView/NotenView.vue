<template>
  <div class="grade-overview">
    <h1>Notenübersicht</h1>
    <table v-if="modules.length > 0" class="grade-table">
      <thead>
      <tr>
        <th>Modul</th>
        <th>Datum</th>
        <th>Credits</th>
        <th>Note</th>
        <th>Status</th>
        <th>Einsicht</th>
      </tr>
      </thead>
      <tbody>
      <tr v-for="(module, index) in modules" :key="index">
        <td>{{ module.Modul }}</td>
        <td>{{ module.Datum }}</td>
        <td>{{ module.Credits }}</td>
        <td>{{ module.Note || '-' }}</td>
        <td>{{ module.Status || '-' }}</td>
        <td>{{ module.Einsicht || '-' }}</td>
      </tr>
      </tbody>
    </table>
    <div v-else class="no-data">Keine Daten verfügbar</div>
  </div>
</template>


<script src="./Noten.vue.js"></script>
<style src="./Noten.vue.css" scoped></style>

