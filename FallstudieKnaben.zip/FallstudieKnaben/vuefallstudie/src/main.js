import { createApp } from 'vue';
import App from './App.vue';
import router from './router';
import axios from 'axios';
import store from './store'; // Importiere den Vuex-Store
import VueCookies from 'vue-cookie';
import {COOKIE_NAME} from "@/store/constants";

const app = createApp(App);

app.use(router);
app.config.globalProperties.$axios = axios;
app.use(store); // Benutze den Vuex-Store

// Überprüfe, ob der Benutzer authentifiziert ist
const authToken = VueCookies.get(COOKIE_NAME);
if (authToken) {
    store.dispatch('login', authToken); // Hier die Authentifizierungsdaten übergeben
}

app.mount('#app');
