const { defineConfig } = require('@vue/cli-service');

module.exports = defineConfig({
  transpileDependencies: true,

  chainWebpack: (config) => {
    config.plugin('define').tap((options) => {
      const opts = options[0];
      opts['__VUE_PROD_DEVTOOLS__'] = false;
      opts['__VUE_OPTIONS_API__'] = true;
      opts['__VUE_PROD_HYDRATE__'] = true;
      opts['__VUE_PROD_HYDRATION_MISMATCH_DETAILS__'] = false; // Hinzugefügt
      return options;
    });
  },
});
